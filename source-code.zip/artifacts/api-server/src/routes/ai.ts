import { Router, type Request } from "express";
import { openai } from "@workspace/integrations-openai-ai-server";
import { db, usersTable, aiTrialsTable, servicesTable } from "@workspace/db";
import { and, asc, desc, eq, ilike, inArray, or, sql, type SQL } from "drizzle-orm";
import { getSession, getSessionId } from "../lib/auth.js";

// ── Free-tier daily quota for AI chat ────────────────────────────
// Main chat tab: 5 messages/day for free users, unlimited for premium.
// Floating chatbot: 15/day during a 3-day free trial, then Premium required.
//   - In-memory map for daily count (resets at midnight UTC).
//   - Persistent table `ai_trials` for the trial start date (resists restarts).
// Premium users: unlimited everywhere.
const FREE_DAILY_LIMIT = 5;
const FLOATING_DAILY_LIMIT = 15;
const FLOATING_TRIAL_DAYS = 3;
const aiChatCounts = new Map<string, { day: string; count: number }>();

function todayKey(): string {
  const d = new Date();
  return `${d.getUTCFullYear()}-${d.getUTCMonth()}-${d.getUTCDate()}`;
}

function bumpQuota(key: string, limit: number = FREE_DAILY_LIMIT): { count: number; limit: number; remaining: number } {
  const today = todayKey();
  const entry = aiChatCounts.get(key);
  if (!entry || entry.day !== today) {
    aiChatCounts.set(key, { day: today, count: 1 });
    return { count: 1, limit, remaining: limit - 1 };
  }
  entry.count += 1;
  // Periodic GC
  if (aiChatCounts.size > 5000) {
    for (const [k, v] of aiChatCounts) {
      if (v.day !== today) aiChatCounts.delete(k);
    }
  }
  return { count: entry.count, limit, remaining: Math.max(0, limit - entry.count) };
}

// Returns the timestamp of the user's first floating-chat message, creating
// the row on first call. Used to enforce the 3-day trial window. Returns null
// only on DB failure (in which case we fail-open and let the request through
// — better UX than blocking everyone if the DB hiccups).
async function getOrCreateTrialStart(clientKey: string): Promise<Date | null> {
  try {
    const [row] = await db
      .insert(aiTrialsTable)
      .values({ clientKey })
      .onConflictDoUpdate({
        target: aiTrialsTable.clientKey,
        // No-op update so the existing startedAt is returned unchanged.
        set: { clientKey: sql`${aiTrialsTable.clientKey}` },
      })
      .returning({ startedAt: aiTrialsTable.startedAt });
    return row?.startedAt ?? null;
  } catch {
    return null;
  }
}

function daysSince(start: Date): number {
  const ms = Date.now() - start.getTime();
  return Math.floor(ms / 86_400_000);
}

async function getUserPremiumStatus(req: Request): Promise<{ isPremium: boolean; userId: string | null }> {
  try {
    const sid = getSessionId(req);
    if (!sid) return { isPremium: false, userId: null };
    const session = await getSession(sid);
    const userId = session?.user?.id;
    if (!userId) return { isPremium: false, userId: null };
    const [u] = await db
      .select({ isPremium: usersTable.isPremium })
      .from(usersTable)
      .where(eq(usersTable.id, userId))
      .limit(1);
    return { isPremium: !!u?.isPremium, userId };
  } catch {
    return { isPremium: false, userId: null };
  }
}

function clientKey(req: Request, userId: string | null): string {
  if (userId) return `u:${userId}`;
  // Use Express's req.ip which respects the `trust proxy` setting so the
  // address is resolved by the trusted reverse proxy layer — NOT the raw
  // X-Forwarded-For header which any caller can spoof.
  const ip = req.ip ?? req.socket.remoteAddress ?? "unknown";
  return `ip:${ip}`;
}

const router = Router();

const SERVICES_CATALOG = `
PROVINCE-WIDE SERVICES (accessible depuis partout au Québec):
- ID:pw1 | 211 Québec | Référence communautaire | Tél:211 | Toutes catégories
- ID:pw2 | Info-Santé 811 | Santé - infirmières 24h | Tél:811
- ID:pw3 | SOS Violence Conjugale | Violence conjugale 24h | Tél:1-800-363-9010
- ID:pw4 | DPJ Protection de la jeunesse | Enfants en danger | Tél:1-800-463-9019
- ID:pw5 | Suicide Action Montréal / Tel-Jeunes | Prévention suicide 24h | Tél:1-866-APPELLE
- ID:pw6 | Tel-Aide Québec | Écoute anonyme | Tél:514-935-1101
- ID:pw7 | Emploi-Québec | Emploi / formations | Tél:1-888-643-4721
- ID:pw8 | TCRI – Réfugiés et demandeurs d'asile | Immigration / asile | Tél:514-272-6060
- ID:pw9 | Regroupement maisons femmes battues | Hébergement femmes violences | Tél:514-879-9010
- ID:pw10 | RSIQ – Hébergement itinérance | Personnes sans abri | Tél:514-933-9373

MONTRÉAL:
- ID:mtl-h1 | Maison du Père | Hébergement hommes sans-abri | Logement urgent
- ID:mtl-h2 | Welcome Hall Mission | Hébergement d'urgence hommes | Logement urgent
- ID:mtl-h3 | Old Brewery Mission | Hébergement / itinérance | Logement urgent
- ID:mtl-h4 | Chez Doris | Refuge femmes vulnérables | Logement urgent
- ID:mtl-h5 | OMHM | Logement social HLM | Logement subventionné
- ID:mtl-f1 | Moisson Montréal | Banque alimentaire | Nourriture urgent
- ID:mtl-f2 | Resto Pop | Café communautaire | Nourriture abordable
- ID:mtl-m1 | Centre de Crise Montréal | Crise psychologique 24h | Santé mentale urgent
- ID:mtl-m2 | Phare Espoir | Soutien santé mentale | Santé mentale
- ID:mtl-he1 | Médecins du Monde | Soins sans papiers / gratuits | Santé urgent
- ID:mtl-fa1 | Maison des femmes Montréal | Femmes en crise / violence | Famille urgent
- ID:mtl-im1 | CARI Saint-Laurent | Intégration immigrants | Immigration
- ID:mtl-s1 | Centraide Montréal | Références communautaires | Social

QUÉBEC (VILLE):
- ID:qc-h1 | Maison Lauberivière | Hébergement itinérance Québec | Logement urgent
- ID:qc-h2 | La Boussole | Hébergement transitoire Québec | Logement urgent
- ID:qc-f1 | Moisson Québec | Banque alimentaire Québec | Nourriture urgent
- ID:qc-m1 | Centre de Crise Québec | Crise psychologique Québec 24h | Santé mentale urgent
- ID:qc-fa1 | Maison Myosotis | Violence conjugale Québec | Famille urgent

LAVAL:
- ID:lav-h1 | Maison de Jonathan | Hébergement urgence Laval | Logement urgent
- ID:lav-f1 | Moisson Laval | Banque alimentaire Laval | Nourriture urgent
- ID:lav-m1 | Centre de Crise Laval | Crise psychologique Laval 24h | Santé mentale urgent

GATINEAU:
- ID:gat-h1 | Maison Montcalm | Hébergement hommes Gatineau | Logement urgent
- ID:gat-f1 | Moisson Outaouais | Banque alimentaire Gatineau | Nourriture urgent
- ID:gat-m1 | Centre de Crise Outaouais | Crise psychologique Gatineau 24h | Santé mentale urgent
- ID:gat-fa1 | Maison Espoir Gatineau | Violence conjugale Gatineau | Famille urgent

LONGUEUIL / MONTÉRÉGIE:
- ID:lng-h1 | Maison Marguerite | Hébergement femmes Longueuil | Logement urgent
- ID:lng-f1 | Moisson Rive-Sud | Banque alimentaire Longueuil | Nourriture urgent
- ID:lng-m1 | Centre de Crise Montérégie | Crise Longueuil 24h | Santé mentale urgent
- ID:sjr-h1 | Maison Sans-Abri St-Jean | Hébergement St-Jean-sur-Richelieu | Logement urgent

SHERBROOKE:
- ID:sher-h1 | La Chaumine | Hébergement itinérance Sherbrooke | Logement urgent
- ID:sher-f1 | Partage Saint-François | Dépannage alimentaire Sherbrooke | Nourriture urgent
- ID:sher-m1 | Centre de Crise Estrie | Crise Sherbrooke 24h | Santé mentale urgent
- ID:sher-fa1 | Maison La Montée | Violence conjugale Sherbrooke | Famille urgent

TROIS-RIVIÈRES (Mauricie):
- ID:tr-hop1 | CHAUR | Hôpital universitaire urgences 24h Trois-Rivières trauma chirurgie | Santé urgent Tél:819-697-3333
- ID:tr-ambu1 | Coopérative Ambulanciers Mauricie | Ambulance Trois-Rivières région TAP soins | Santé urgent Tél:819-374-4444
- ID:tr-h1 | Le Havre | Hébergement urgence hommes Trois-Rivières 24h | Logement urgent
- ID:tr-h2 | Mission de l'Espoir | Refuge hommes sans abri Trois-Rivières | Logement urgent
- ID:tr-h3 | Carrefour Le Mitan | Logement transitoire Trois-Rivières | Logement
- ID:tr-f1 | Moisson Mauricie/CDQ | Banque alimentaire Trois-Rivières | Nourriture urgent
- ID:tr-f2 | Saint-Vincent-de-Paul TR | Alimentation, vêtements, mobilier | Nourriture/Social
- ID:tr-m1 | Centre de Crise Mauricie | Crise Trois-Rivières 24h | Santé mentale urgent
- ID:tr-fa1 | La Séjournelle | Violence conjugale Trois-Rivières | Famille urgent
- ID:tr-health1 | CLSC Trois-Rivières CIUSSS MCQ | Soins santé, services sociaux | Santé Tél:819-370-2100
- ID:tr-emp1 | CJE Mauricie | Emploi jeunes 16-35 ans Trois-Rivières | Emploi Tél:819-375-1313
- ID:tr-emp2 | Emploi-Québec Trois-Rivières | Aide emploi, formations | Emploi Tél:1-888-643-4721
- ID:tr-fam1 | Centre-femmes Mauricie | Soutien femmes Trois-Rivières | Famille Tél:819-378-9373
- ID:tr-legal1 | Aide juridique Mauricie | Droit gratuit faible revenu TR | Juridique Tél:819-371-6711
- ID:tr-social1 | Centraide Mauricie | Référence 60+ organismes locaux | Social Tél:819-374-3676
- ID:tr-immig1 | CITIM Mauricie | Immigration, intégration TR | Immigration Tél:819-372-4655
- ID:tr-cavac | CAVAC Mauricie-CDQ | Victimes actes criminels TR | Famille urgent Tél:819-373-0318
- ID:tr-drop | Drogue Aide Référence TR | Dépendances TR/Mauricie | Santé mentale urgent

SHAWINIGAN (Mauricie):
- ID:shaw-hop1 | Hôpital Centre-de-la-Mauricie | Hôpital urgences 24h Shawinigan chirurgie obstétrique | Santé urgent Tél:819-536-7500
- ID:shaw-ambu1 | Ambulance 22-22 Shawinigan | Ambulance locale Shawinigan Grand-Mère | Santé urgent Tél:819-536-2222
- ID:shaw-caserne | Caserne pompiers Champlain Shawinigan | Incendie sauvetage Shawinigan | Social urgent
- ID:shaw-f1 | Dépannage Alimentaire Shawinigan | Aide alimentaire urgence Shawinigan | Nourriture urgent
- ID:shaw-food2 | Moisson Mauricie dist. Shawinigan | Paniers alimentaires Shawinigan | Nourriture urgent
- ID:shaw-h1 | La Chrysalide | Maison hébergement femmes violences Shawinigan 24h | Famille urgent
- ID:shaw-h2 | Hébergement La Vigile | Hébergement urgence sans abri Shawinigan | Logement urgent
- ID:shaw-health1 | CLSC Shawinigan CIUSSS MCQ | Soins santé Shawinigan | Santé Tél:819-536-7500
- ID:shaw-mh1 | Centre de Crise Mauricie (Shawinigan) | Crise 24h Shawinigan | Santé mentale urgent
- ID:shaw-emp1 | CJE Shawinigan | Emploi jeunes Shawinigan | Emploi Tél:819-537-0111
- ID:shaw-fam1 | Centre-femmes Shawinigan | Soutien femmes Shawinigan | Famille Tél:819-537-8261
- ID:shaw-social1 | Saint-Vincent-de-Paul Shawinigan | Aide matérielle Shawinigan | Social
- ID:shaw-legal1 | Aide juridique Shawinigan | Droit gratuit faible revenu Shawinigan | Juridique

DRUMMONDVILLE (Centre-du-Québec):
- ID:drum-hop1 | Hôpital Sainte-Croix | Hôpital urgences 24h Drummondville chirurgie soins intensifs | Santé urgent Tél:819-478-6464
- ID:drum-ambu1 | CAM Centre-du-Québec | Ambulance Drummondville TAP soins préhospitaliers | Santé urgent Tél:819-478-2323
- ID:drum-siuc | SIUCQ | Urgence civile évacuation sinistre Drummondville CDQ | Social urgent
- ID:drum-h1 | Maison Coup d'Éclat | Violence conjugale Drummondville 24h | Famille urgent Tél:819-477-8644
- ID:drum-h2 | Les Escales de Drummond | Logement transitoire Drummondville | Logement
- ID:drum-mh1 | Centre de Crise CDQ | Crise Drummondville 24h | Santé mentale urgent Tél:819-477-2433
- ID:drum-health1 | CLSC Drummond CIUSSS MCQ | Soins santé Drummondville | Santé Tél:819-474-2572
- ID:drum-emp1 | CJE Drummond | Emploi jeunes Drummondville | Emploi Tél:819-474-1463
- ID:drum-fam1 | Centre-femmes l'Essentielle | Soutien femmes Drummondville | Famille Tél:819-474-2381
- ID:drum-immig1 | CAID Drummondville | Immigration intégration Drummondville | Immigration Tél:819-474-0961
- ID:drum-legal1 | Aide juridique Drummondville | Droit gratuit Drummondville | Juridique Tél:819-478-0540
- ID:drum-social1 | Centraide CDQ | Référence organismes Centre-du-Québec | Social Tél:819-472-6444
- ID:drum-food2 | L'Armoire du Placard | Épicerie communautaire Drummondville | Nourriture
- ID:drum-cavac | CAVAC CDQ Drummondville | Victimes actes criminels Drummondville | Famille urgent

VICTORIAVILLE (Centre-du-Québec / Arthabaska):
- ID:vic-hop1 | Hôtel-Dieu d'Arthabaska | Hôpital urgences 24h Victoriaville trauma chirurgie oncologie | Santé urgent Tél:819-357-2030
- ID:vic-ambu1 | Ambulanciers Arthabaska-L'Érable | Ambulance Victoriaville Plessisville TAP | Santé urgent Tél:819-752-4444
- ID:vic-h1 | La Montée | Maison hébergement femmes violences Victoriaville 24h | Famille urgent Tél:819-758-6066
- ID:vic-h2 | Accueil-Gîte | Hébergement urgence Victoriaville | Logement urgent
- ID:vic-food1 | Moisson Arthabaska | Banque alimentaire Victoriaville région | Nourriture urgent Tél:819-752-7700
- ID:vic-mh1 | Centre de Crise CDQ (Victoriaville) | Crise 24h Victoriaville | Santé mentale urgent
- ID:vic-health1 | CLSC Arthabaska-L'Érable | Soins santé Victoriaville | Santé Tél:819-357-2100
- ID:vic-emp1 | CJE Arthabaska-L'Érable | Emploi jeunes Victoriaville | Emploi Tél:819-758-2088
- ID:vic-fam1 | Centre-femmes Victoriaville | Soutien femmes Victoriaville | Famille Tél:819-758-6262
- ID:vic-legal1 | Aide juridique Victoriaville | Droit gratuit Victoriaville | Juridique Tél:819-752-2231
- ID:vic-social1 | Saint-Vincent-de-Paul Victoriaville | Aide matérielle Victoriaville | Social
- ID:vic-social2 | REA Victoriaville | Entraide, visites amitié, soutien aînés | Social
- ID:vic-cavac | CAVAC CDQ Victoriaville | Victimes actes criminels Victoriaville | Famille urgent

SAGUENAY:
- ID:sag-h1 | Centre Le Havre | Hébergement Saguenay | Logement urgent
- ID:sag-f1 | Moisson Saguenay-LSJ | Banque alimentaire Saguenay | Nourriture urgent
- ID:sag-m1 | Centre de Crise Saguenay | Crise Saguenay 24h | Santé mentale urgent

SAINT-JÉRÔME (LAURENTIDES):
- ID:jer-h1 | Maison du Réconfort | Hébergement Laurentides | Logement urgent
- ID:jer-f1 | Moisson Laurentides | Banque alimentaire St-Jérôme | Nourriture urgent
- ID:jer-m1 | Centre de Crise Laurentides | Crise Laurentides 24h | Santé mentale urgent

AUTRES RÉGIONS:
- ID:rn-h1 | Maison Hébergement Rouyn-Noranda | Hébergement Abitibi | Logement urgent
- ID:rn-f1 | Moisson Abitibi-Témiscamingue | Banque alimentaire Abitibi | Nourriture urgent
- ID:vdo-h1 | La Piaule Val-d'Or | Hébergement Val-d'Or | Logement urgent
- ID:rim-h1 | Maison l'Alcôve | Hébergement femmes Rimouski | Famille urgent
- ID:si-h1 | Centre Hébergement Sept-Îles | Hébergement Côte-Nord | Logement urgent
- ID:gasp-fa1 | Maison Hébergement Gaspé | Violence conjugale Gaspésie | Famille urgent
- ID:lev-h1 | Maison Revivre Lévis | Hébergement Lévis | Logement urgent
- ID:jol-h1 | Centre Hébergement Joliette | Hébergement Lanaudière | Logement urgent

AÎNÉS — LIGNES PROVINCIALES & SOUTIEN (province-wide):
- ID:qc-prov-seniors-001 | Ligne Aide Abus Aînés | Maltraitance aînés 7j/7 8h-20h | Tél:1-888-489-2287 | URGENT
- ID:qc-prov-seniors-002 | Tel-Aînés | Écoute 50+ isolement solitude détresse | Tél:514-353-2463
- ID:qc-prov-seniors-003 | Info-Abus Aînés (211) | Référence locale aînés gratuite 7j/7 | Tél:211
- ID:qc-prov-seniors-004 | Petits Frères | Jumelage bénévole aînés isolés (MTL/QC/TR/Sherb/Granby/Lanaudière) | Tél:514-527-8653
- ID:qc-prov-seniors-005 | Présâges | Crise aînés isolement abus négligence | Tél:514-273-4774
- ID:qc-prov-seniors-006 | FADOQ — Réseau provincial | Carte rabais + activités locales aînés | Tél:1-800-544-9058
- ID:qc-prov-seniors-007 | Société Alzheimer du Québec | Info Alzheimer/démence + 20 sociétés régionales | Tél:1-800-444-8762
- ID:qc-prov-seniors-008 | L'Appui proches aidants | Info-aidant 8h-20h 7j/7 gratuit | Tél:1-855-852-7784
- ID:qc-prov-seniors-009 | Curateur public du Québec | Protection aînés inaptes mandat | Tél:1-844-532-8728
- ID:qc-prov-seniors-010 | Pension Sécurité vieillesse (PSV) | 65+ Service Canada | Tél:1-800-277-9915
- ID:qc-prov-seniors-011 | Supplément revenu garanti (SRG) | Aînés faible revenu (avec PSV) | Tél:1-800-277-9915
- ID:qc-prov-seniors-012 | Retraite Québec (RRQ) | Rente retraite 60-65+ | Tél:1-800-463-5185
- ID:qc-prov-seniors-013 | Crédit maintien à domicile (RAMQ) | 70+ jusqu'à 38% services à domicile | Tél:1-855-291-6467
- ID:qc-prov-seniors-014 | Commissaire local aux plaintes | Plainte CHSLD/RPA/CLSC/hôpital | Tél:811
- ID:qc-prov-seniors-015 | AQDR | Défense droits aînés 40 sections QC | Tél:514-935-1551

AÎNÉS — POPOTE ROULANTE & TRANSPORT ADAPTÉ (régional):
- ID:qc-mtl-seniors-001 | Popote roulante Montréal métropolitain | Repas chauds ~7$ MTL+Laval | Tél:514-256-5571
- ID:qc-mtl-seniors-002 | Transport adapté STM | Porte-à-porte aînés/PMR Montréal réservation 24h | Tél:514-280-8211
- ID:qc-mtl-seniors-003 | Société Alzheimer de Montréal | Soutien proches + groupes répit | Tél:514-369-0800
- ID:qc-mtl-seniors-004 | FADOQ — Île de Montréal | Activités/rabais aînés MTL | Tél:514-271-1411
- ID:qc-qc-seniors-001 | Popote roulante Québec (CAB Québec) | Popote + transport médical aînés | Tél:418-681-3501
- ID:qc-qc-seniors-002 | Transport adapté STAC (RTC Québec) | PMR/aînés région Québec | Tél:418-687-2641
- ID:qc-qc-seniors-003 | Société Alzheimer Québec | Soutien + ateliers stimulation cognitive | Tél:418-527-4294
- ID:qc-qc-seniors-004 | FADOQ — Québec et Chaudière-Appalaches | Clubs aînés régionaux | Tél:418-650-3552
- ID:qc-lvl-seniors-001 | Popote roulante Laval (Centre du Sablon) | Repas chauds aînés Laval | Tél:450-688-3247
- ID:qc-lvl-seniors-002 | Transport adapté STL (Laval) | PMR/aînés Laval | Tél:450-662-5400
- ID:qc-lng-seniors-001 | Popote roulante Longueuil (CAB Rive-Sud) | Popote + accompagnement transport + visites | Tél:450-651-9356
- ID:qc-lng-seniors-002 | Transport adapté RTL (Longueuil) | PMR/aînés Rive-Sud | Tél:450-463-0131
- ID:qc-gat-seniors-001 | Popote roulante Gatineau (Entr'Aînés) | Repas + visites + accompagnement Outaouais | Tél:819-243-2727
- ID:qc-gat-seniors-002 | Transport adapté STO (Gatineau) | PMR/aînés Outaouais | Tél:819-595-3999
- ID:qc-shrb-seniors-001 | Popote roulante Sherbrooke | Repas chauds aînés/convalescents lun-ven | Tél:819-823-2792
- ID:qc-shrb-seniors-002 | Société Alzheimer Estrie | Soutien Alzheimer + proches aidants | Tél:819-821-5127
- ID:qc-tr-seniors-001 | Popote roulante Trois-Rivières (CAB Laviolette) | Popote + transport médical + visites | Tél:819-373-0709
- ID:qc-sag-seniors-001 | Popote roulante Saguenay (CAB Saguenay) | Popote + transport bénévole + visites | Tél:418-545-7888

SERVICES DE GARDE — CPE & GARDERIES (province-wide):
- ID:cpe-pw1 | Mon Enfant – Liste d'attente CPE | Portail inscription CPE/garderies subventionnées (~10$/jour) | Tél:1-877-644-4545 | Site:monenfant.ca
- ID:cpe-pw2 | Ministère de la Famille – Aide financière garde | Subventions, aide urgence, crédit d'impôt frais de garde | Tél:1-877-644-4545
- ID:cpe-pw3 | Garde en milieu familial (RSG) | Réseau RSG à domicile, subventionné ~10$/jour | Site:monenfant.ca
- ID:cpe-urg1 | SOS Garde – Dépannage urgence garde | Garde d'urgence (violence conjugale, hospitalisation) | Tél:514-876-1158 | URGENT

SERVICES DE GARDE — RÉGIONS:
- ID:cpe-mtl1 | CPE Les Coccinelles | Montréal, CPE subventionné 0-5 ans ~10$/jour
- ID:cpe-mtl2 | CPE La Ruche – Rosemont | Montréal, CPE communautaire subventionné
- ID:cpe-mtl3 | Programme places à 0$ | Montréal, garderie non subventionnée avec aide financière
- ID:cpe-mtl4 | YMCA Services de garde | Montréal, avant/après-école, tarifs modulés selon revenu
- ID:cpe-qc1 | CPE Pas à Pas | Québec, CPE subventionné 0-5 ans
- ID:cpe-qc2 | Centre de la Famille Ste-Foy | Québec, CPE communautaire subventionné
- ID:cpe-lav1 | CPE Les Petits Amis | Laval, CPE subventionné
- ID:cpe-lav2 | Garderie La Petite Étoile | Laval, garderie non subventionnée (crédit d'impôt disponible)
- ID:cpe-gat1 | CPE Les Petits Poucets | Gatineau, CPE subventionné 0-5 ans
- ID:cpe-gat2 | Regroupement des CPE Outaouais | Gatineau, orientation vers CPE de la région
- ID:cpe-sher1 | CPE La Maison de Carton | Sherbrooke, CPE subventionné
- ID:cpe-tr1 | CPE Au Jardin d'Enfants | Trois-Rivières, CPE subventionné
- ID:cpe-sag1 | CPE Le Pionnier | Saguenay, CPE subventionné
- ID:cpe-lng1 | CPE Les Petits Loups | Longueuil, CPE subventionné
- ID:cpe-jer1 | CPE Les Castors | Saint-Jérôme, CPE subventionné Laurentides

ACHAT IMMOBILIER — PROGRAMMES GOUVERNEMENTAUX (province-wide):
- ID:re-pw1 | SCHL | Assurance hypothécaire fédérale, mise de fonds 5%-19,99%, guides premier acheteur | Tél:1-800-668-2642
- ID:re-pw2 | RAP – Régime accession propriété (REER) | Retrait jusqu'à 35 000$ REER sans impôt | Tél:1-800-959-8281
- ID:re-pw3 | CELIAPP | Épargne jusqu'à 40 000$ exonérée d'impôt pour première propriété | Tél:1-800-959-8281
- ID:re-pw4 | Centris.ca | Toutes les propriétés à vendre au Québec | Tél:514-762-2440
- ID:re-pw5 | DuProprio | Propriétés sans courtier, moins cher | Tél:1-866-387-7677
- ID:re-assist1 | OACIQ | Vérification courtiers certifiés, droits de l'acheteur | Tél:1-800-440-7170
- ID:re-assist2 | Chambre des notaires Québec | Notaire obligatoire pour acte de vente, 1000$-1800$ | Tél:1-800-263-1793

ACHAT IMMOBILIER — BANQUES ET FINANCEMENT (province-wide):
- ID:re-bank1 | Desjardins | Caisse québécoise, taux compétitifs, programme premiers acheteurs | Tél:1-800-224-7737
- ID:re-bank2 | Banque Nationale | Banque québécoise, solutions nouveaux arrivants | Tél:1-888-835-6281
- ID:re-bank3 | RBC Banque Royale | Programme Première Maison, mise de fonds réduite | Tél:1-800-769-2511
- ID:re-bank4 | TD Canada Trust | Approbation rapide, programme premier acheteur | Tél:1-866-222-3456
- ID:re-bank5 | BMO Banque de Montréal | Remboursement anticipé 20%, refinancement | Tél:1-877-225-5266
- ID:re-bank6 | Scotiabank | Aide aux nouveaux arrivants, programme STEP | Tél:1-800-472-6842
- ID:re-bank7 | Banque Laurentienne | Taux compétitifs, travailleurs autonomes | Tél:1-877-522-3863

ACHAT IMMOBILIER — MARCHÉS RÉGIONAUX (prix médian maison, du moins au plus cher):
- ID:re-sag1 | Saguenay | Le moins cher : 150 000$–280 000$ | Idéal budget limité
- ID:re-tr1 | Trois-Rivières | Très abordable : 200 000$–320 000$ | Bonne qualité de vie
- ID:re-rn1 | Abitibi-Témiscamingue (Rouyn-Noranda) | Abordable : 180 000$–300 000$ | Fort marché emploi
- ID:re-sher1 | Sherbrooke | Abordable : 250 000$–380 000$ | Ville universitaire
- ID:re-qc1 | Québec (ville) | Modéré : 280 000$–500 000$ | Qualité de vie élevée
- ID:re-gat1 | Gatineau | Modéré : 300 000$–480 000$ | Emplois fédéraux, proximité Ottawa
- ID:re-lng1 | Longueuil / Rive-Sud | Modéré : 380 000$–600 000$ | Accès métro Montréal
- ID:re-lav1 | Laval | Modéré à élevé : 450 000$–700 000$ | Métro Orange, île entre deux villes
- ID:re-mtl1 | Montréal | Le plus cher : 350 000$–1 100 000$+ | Quartiers abordables : Montréal-Nord, RDP (200K-450K)

PROCÉDURE D'ACHAT IMMOBILIER AU QUÉBEC (à expliquer si demandé):
1. PRÉQUALIFICATION : Contactez une banque ou Desjardins pour connaître votre capacité d'emprunt
2. ÉPARGNE MISE DE FONDS : Minimum 5% du prix si <500K$, 10% pour tranche 500K$-999K$. Utilisez RAP ou CELIAPP
3. RECHERCHE : Centris.ca (avec courtier) ou DuProprio (sans courtier)
4. OFFRE D'ACHAT : Votre courtier ou vous-même rédigez une offre avec conditions (financement, inspection)
5. INSPECTION PRÉ-ACHAT : Obligatoire — inspecteur en bâtiment certifié (~500$-800$)
6. FINANCEMENT FINAL : La banque confirme l'hypothèque. SCHL si mise de fonds <20%
7. NOTAIRE : Acte de vente chez le notaire (~1000$-1800$). Transfert de propriété officiel
8. REMISE DES CLÉS : Prise de possession à la date convenue
`.trim();

const EMERGENCY_CATALOG = `
SERVICES D'URGENCE DE PREMIÈRE LIGNE — QUÉBEC:

CENTRES 911 (dispatch temps réel):
- 911 Montréal | Centre dispatch Île de Montréal | Tél:911
- 911 Québec | Centre dispatch Ville de Québec | Tél:911
- 911 Laval | Centre dispatch Laval | Tél:911
- 911 Longueuil | Centre dispatch agglomération Longueuil | Tél:911
- 911 Gatineau–Outaouais | Centre dispatch Outaouais | Tél:911
- 911 Sherbrooke–Estrie | Centre dispatch Estrie | Tél:911
- 911 Saguenay–Lac-Saint-Jean | Centre dispatch Saguenay | Tél:911
- 911 Trois-Rivières–Mauricie | Centre dispatch Mauricie | Tél:911
- 911 Lévis–Chaudière-Appalaches | Centre dispatch Rive-Sud | Tél:911
- 911 Lanaudière | Centre dispatch Lanaudière | Tél:911
- 911 Laurentides | Centre dispatch Laurentides | Tél:911
- 911 Montérégie | Centre dispatch Montérégie | Tél:911
- 911 Centre-du-Québec | Centre dispatch Centre-du-Québec | Tél:911
- 911 Abitibi–Témiscamingue | Centre dispatch Abitibi | Tél:911
- 911 Bas-Saint-Laurent | Centre dispatch Bas-Saint-Laurent | Tél:911
- 911 Gaspésie–Îles-de-la-Madeleine | Centre dispatch Gaspésie | Tél:911
- 911 Côte-Nord | Centre dispatch Côte-Nord | Tél:911
- 911 Nord-du-Québec | Centre dispatch Nord-du-Québec | Tél:911
- 911 Nunavik | Centre dispatch Nunavik (évacuations aériennes) | Tél:911

POLICE:
- Sûreté du Québec (SQ) | Police provinciale — couvre toutes les municipalités sans service municipal | Tél:1-800-461-2131 / 911
- SPVM | Service de police Montréal | Tél:514-280-2222 / 911
- SPQ | Service de police Québec | Tél:418-641-6411 / 911
- SPL | Service de police Laval | Tél:450-662-4636 / 911
- SPAL | Police agglomération Longueuil | Tél:450-463-7211 / 911
- SPG | Police Gatineau | Tél:819-246-0222 / 911
- SPS | Police Sherbrooke | Tél:819-821-8000 / 911
- SPS | Police Saguenay | Tél:418-545-5778 / 911
- SPTR | Police Trois-Rivières | Tél:819-691-2929 / 911
- GRC Québec | Police fédérale, crimes organisés | Tél:514-939-8300 / 911

INCENDIE (pompiers):
- SIM | Service incendie Montréal — 66 casernes | Tél:514-872-3800 / 911
- Service incendie Québec | Tél:418-641-6800 / 911
- SSIL | Service incendie Laval | Tél:450-662-4900 / 911
- Service incendie Longueuil | Tél:450-646-8800 / 911
- SIG | Service incendie Gatineau | Tél:819-595-7777 / 911
- Service incendie Sherbrooke | Tél:819-821-5600 / 911
- Service incendie Saguenay | Tél:418-698-3000 / 911
- Service incendie Trois-Rivières | Tél:819-379-4600 / 911
- Service incendie Lévis | Tél:418-833-7777 / 911
⚠️ Plus de 700 services incendie municipaux au Québec — pour toute urgence incendie : 911

AMBULANCE / SOINS PRÉHOSPITALIERS:
- Urgences-santé | Montréal et Laval | Tél:514-842-4242 / 911
- CETAM | Montérégie | Tél:450-677-4411 / 911
- Services préhospitaliers Québec | Capitale-Nationale | Tél:418-529-4141 / 911
- Services ambulanciers Estrie | Tél:819-562-9341 / 911
- Services ambulanciers Mauricie–Centre-du-Québec | Tél:819-697-3333 / 911
- Services ambulanciers Outaouais | Tél:819-771-7444 / 911
- Services ambulanciers Saguenay–Lac-Saint-Jean | Tél:418-541-1000 / 911
- Services ambulanciers Laurentides | Tél:450-569-3311 / 911
- Services ambulanciers Lanaudière | Tél:450-759-8222 / 911
- Services ambulanciers Abitibi–Témiscamingue | Tél:819-764-5131 / 911
- Services ambulanciers Bas-Saint-Laurent | Tél:418-724-5231 / 911
- Services ambulanciers Côte-Nord | Tél:418-962-8811 / 911
- Services ambulanciers Chaudière-Appalaches | Tél:418-380-8996 / 911
⚠️ 773 des 1 112 municipalités du Québec n'ont pas de premiers répondants — délais possibles en zone rurale

DISTANCES ENTRE LES 4 VILLES PRIORITAIRES (Mauricie / Centre-du-Québec):
- Trois-Rivières → Shawinigan : ~30 km (autoroute 55, ~25 min)
- Trois-Rivières → Drummondville : ~70 km (autoroute 55, ~50 min)
- Trois-Rivières → Victoriaville : ~95 km (autoroute 55, ~1h05)
- Drummondville → Victoriaville : ~60 km (autoroute 55, ~45 min)
⚠️ HÔPITAUX SPÉCIALISÉS: Si patient doit être transféré depuis Shawinigan → CHAUR Trois-Rivières (trauma, cardiologie, neurologie) = 30 km. Depuis Victoriaville → CHAUR ou CHU de Québec selon la spécialité.
💡 Si personne à Shawinigan demande ambulance: Ambulance 22-22 (819-536-2222), urgences à l'Hôpital Centre-de-la-Mauricie.
💡 Si personne à Drummondville demande ambulance: CAM CDQ (819-478-2323), urgences à l'Hôpital Sainte-Croix.
💡 Si personne à Victoriaville demande ambulance: Services ambulanciers Arthabaska (819-752-4444), urgences à l'Hôtel-Dieu d'Arthabaska.

DÉPENDANCES ET LIGNES DE CRISE SPÉCIALISÉES:
- Drogue : aide et référence | Dépendances drogue/alcool 24h | Tél:1-800-265-2626
- Jeu : aide et référence | Jeu compulsif 24h | Tél:1-800-461-0140
- AA Québec | Alcooliques Anonymes | Tél:514-376-9230
- NA Québec | Narcotiques Anonymes | Tél:514-249-0555
- RQCALACS | Agressions sexuelles | Tél:1-888-933-9007
- Ligne Aide Abus Aînés | Maltraitance aînés | Tél:1-888-489-2287
- SOS Grossesse | Grossesse en crise 24h | Tél:1-800-463-5655
- Tel-Jeunes | Jeunes 12-25 ans 24h | Tél:1-800-263-2266
- Jeunesse j'écoute | Jeunes Canadiens 24h | Tél:1-800-668-6868
- Traite des personnes | Ligne nationale | Tél:1-833-900-1010
- Info-Crime Québec | Signalement anonyme | Tél:1-800-711-1800
- Croix-Rouge canadienne | Sinistres / catastrophes | Tél:1-800-418-1111
- Sécurité civile Québec | Sinistrés, indemnisation | Tél:1-800-363-1363

═══════════════════════════════════════════════════════════════════
SERVICES ADMINISTRATIFS — AUTRES PROVINCES ET TERRITOIRES DU CANADA
═══════════════════════════════════════════════════════════════════
⚠️ Pour ces 12 régions, AttenteZéro couvre uniquement le 211 (référence
communautaire) et les services administratifs gouvernementaux principaux
(Service Canada + service provincial). Pour tout autre besoin, oriente
l'usager vers le 211 de sa province qui connaît tous les organismes locaux.

ONTARIO (ON):
- ID:pw-211-on | 211 Ontario | Référence communautaire toutes catégories | Tél:211
- ID:on-service-canada-toronto | Service Canada — Centre Toronto Nord | Démarches fédérales (AE, NAS, pension) | Tél:1-800-622-6232
- ID:on-serviceontario-bay | ServiceOntario — Bay & College (Toronto) | Démarches provinciales (permis, carte santé) | Tél:1-800-267-8097
- ID:311-tor | 311 Toronto | Services municipaux Toronto | Tél:311

ALBERTA (AB):
- ID:pw-211-ab | 211 Alberta | Référence communautaire | Tél:211
- ID:ab-service-canada-calgary | Service Canada — Centre Calgary Harry Hays | Démarches fédérales | Tél:1-800-622-6232
- ID:ab-service-alberta-edmonton | Service Alberta — Edmonton (registres) | Démarches provinciales | Tél:780-427-7013

COLOMBIE-BRITANNIQUE (BC):
- ID:pw-211-bc | 211 Colombie-Britannique | Référence communautaire | Tél:211
- ID:bc-service-canada-vancouver | Service Canada — Centre Vancouver | Démarches fédérales | Tél:1-800-622-6232
- ID:bc-servicebc-vancouver | Service BC — Centre Vancouver | Démarches provinciales | Tél:1-800-663-7867

MANITOBA (MB):
- ID:pw-211-mb | 211 Manitoba | Référence communautaire | Tél:211
- ID:mb-service-canada-winnipeg | Service Canada — Centre Winnipeg | Démarches fédérales | Tél:1-800-622-6232
- ID:mb-gov-inquiry-winnipeg | Manitoba Government Inquiry — Winnipeg | Démarches provinciales | Tél:1-866-626-4862

SASKATCHEWAN (SK):
- ID:pw-211-sk | 211 Saskatchewan | Référence communautaire | Tél:211
- ID:sk-service-canada-regina | Service Canada — Centre Regina | Démarches fédérales | Tél:1-800-622-6232
- ID:sk-isc-regina | Information Services Corporation (ISC) — Regina | Démarches provinciales | Tél:1-866-275-4721

NOUVEAU-BRUNSWICK (NB):
- ID:pw-211-nb | 211 Nouveau-Brunswick | Référence communautaire | Tél:211
- ID:nb-service-canada-fredericton | Service Canada — Centre Fredericton | Démarches fédérales | Tél:1-800-622-6232
- ID:nb-snb-fredericton | Service Nouveau-Brunswick — Fredericton | Démarches provinciales | Tél:1-888-762-8600

NOUVELLE-ÉCOSSE (NS):
- ID:pw-211-ns | 211 Nouvelle-Écosse | Référence communautaire | Tél:211
- ID:ns-service-canada-halifax | Service Canada — Centre Halifax | Démarches fédérales | Tél:1-800-622-6232
- ID:ns-access-ns-halifax | Access Nova Scotia — Halifax | Démarches provinciales | Tél:1-800-670-4357

ÎLE-DU-PRINCE-ÉDOUARD (PE):
- ID:pw-211-pe | 211 Île-du-Prince-Édouard | Référence communautaire | Tél:211
- ID:pe-service-canada-charlottetown | Service Canada — Centre Charlottetown | Démarches fédérales | Tél:1-800-622-6232
- ID:pe-access-pei-charlottetown | Access PEI — Charlottetown | Démarches provinciales | Tél:1-902-368-5200

TERRE-NEUVE-ET-LABRADOR (NL):
- ID:pw-211-nl | 211 Terre-Neuve-et-Labrador | Référence communautaire | Tél:211
- ID:nl-service-canada-stjohns | Service Canada — Centre St. John's | Démarches fédérales | Tél:1-800-622-6232
- ID:nl-digital-gov-stjohns | Digital Government and Service NL — St. John's | Démarches provinciales | Tél:1-709-729-4834

YUKON (YT):
- ID:pw-211-yt | 211 Yukon | Référence communautaire | Tél:211
- ID:yk-svc-canada | Service Canada — Centre Whitehorse | Démarches fédérales | Tél:1-800-622-6232
- ID:yk-yg-info | Yukon Government — Information & Services | Démarches territoriales | Tél:1-867-667-5811

TERRITOIRES DU NORD-OUEST (NT):
- ID:pw-211-nt | 211 Territoires du Nord-Ouest | Référence communautaire | Tél:211
- ID:nt-svc-canada | Service Canada — Centre Yellowknife | Démarches fédérales | Tél:1-800-622-6232
- ID:nt-gov-info | Gouvernement des T.N.-O. — Renseignements | Démarches territoriales | Tél:1-867-767-9100

NUNAVUT (NU):
- ID:pw-211-nu | Nunavut Kamatsiaqtut Helpline | Soutien crise/santé mentale 24h | Tél:1-800-265-3333
- ID:nu-svc-canada | Service Canada — Centre Iqaluit | Démarches fédérales | Tél:1-800-622-6232
- ID:nu-gn-info | Gouvernement du Nunavut — Renseignements | Démarches territoriales | Tél:1-867-975-5300
`.trim();

function getQuebecTimeContext(): string {
  const now = new Date();
  const quebecTime = new Date(now.toLocaleString("en-US", { timeZone: "America/Montreal" }));
  const hour = quebecTime.getHours();
  const month = quebecTime.getMonth() + 1;
  const dayOfWeek = quebecTime.getDay();
  const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
  const dayName = ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"][dayOfWeek];

  const risks: string[] = [];

  if (hour >= 22 || hour < 6) {
    risks.push("NUIT (22h–6h) : risques accrus de violence, intoxication, accidents de la route, hypothermie");
  }
  if ((hour >= 7 && hour <= 9) || (hour >= 16 && hour <= 18)) {
    risks.push("HEURE DE POINTE : risques élevés d'accidents de la route et de surcharge des services d'urgence");
  }
  if (isWeekend && hour >= 20) {
    risks.push("SOIRÉE DE FIN DE SEMAINE : risques accrus d'intoxication à l'alcool/drogues, violences, accidents");
  }
  if (month >= 12 || month <= 2) {
    risks.push("HIVER : risques d'hypothermie pour personnes sans abri, verglas, accidents de la route, chutes");
  }
  if (month === 3 || month === 4) {
    risks.push("DÉGEL PRINTANIER : risques d'inondations, glaces instables, crues subites en région");
  }
  if (month >= 6 && month <= 8) {
    risks.push("ÉTÉ : coups de chaleur, noyades, accidents vélos/motos, incendies de forêt possible en région");
  }

  return `
CONTEXTE TEMPOREL ACTUEL (Québec):
- Heure locale : ${quebecTime.toLocaleTimeString("fr-CA", { hour: "2-digit", minute: "2-digit" })} (${dayName})
- Mois : ${quebecTime.toLocaleDateString("fr-CA", { month: "long", year: "numeric" })}
${risks.length > 0 ? `- Alertes de risques actives :\n  • ${risks.join("\n  • ")}` : "- Pas d'alerte de risque particulière pour ce moment"}
`.trim();
}

/* ────────────────────────────────────────────────────────────────────
 * RAG retrieval (Option A) — May 2026
 *
 * Why: the static SERVICES_CATALOG above only carries ~250 services, but the
 * production DB has ~8 000. Without retrieval the model either invents
 * numbers or admits ignorance for 97% of the catalog. We extract keywords
 * (city + category + urgency) from the user's question, run a cheap
 * server-side lookup against the live `services` table, and inject the
 * top 15 matches into the system prompt.
 *
 * The static SERVICES_CATALOG is kept ONLY as a fail-soft fallback when the
 * DB lookup throws or returns nothing — guarantees we never regress UX.
 * EMERGENCY_CATALOG (911 dispatch + crisis lines) is always included.
 * ──────────────────────────────────────────────────────────────────── */

type Keywords = { cities: string[]; categories: string[]; isUrgent: boolean };

const CITY_PATTERNS: { canonical: string; patterns: RegExp[] }[] = [
  { canonical: "Montréal", patterns: [/\bmont(?:r[ée]al)?\b/i, /\bmtl\b/i] },
  { canonical: "Québec", patterns: [/\bville\s+de\s+qu[ée]bec\b/i, /\bqu[ée]bec\s+(?:ville|city)\b/i] },
  { canonical: "Laval", patterns: [/\blaval\b/i] },
  { canonical: "Gatineau", patterns: [/\bgatineau\b/i, /\bhull\b/i, /\boutaouais\b/i] },
  { canonical: "Longueuil", patterns: [/\blongueuil\b/i, /\brive[-\s]?sud\b/i] },
  { canonical: "Sherbrooke", patterns: [/\bsherbrooke\b/i, /\bestrie\b/i] },
  { canonical: "Trois-Rivières", patterns: [/\btrois[-\s]?rivi[eè]res?\b/i, /\bmauricie\b/i] },
  { canonical: "Shawinigan", patterns: [/\bshawinigan\b/i] },
  { canonical: "Drummondville", patterns: [/\bdrummond(?:ville)?\b/i] },
  { canonical: "Victoriaville", patterns: [/\bvictoriaville\b/i, /\barthabaska\b/i] },
  { canonical: "Saguenay", patterns: [/\bsaguenay\b/i, /\bchicoutimi\b/i, /\bjonqui[eè]re\b/i] },
  { canonical: "Saint-Jérôme", patterns: [/\bsaint?[-\s]?j[ée]r[ôo]me\b/i, /\blaurentides\b/i] },
  { canonical: "Rouyn-Noranda", patterns: [/\brouyn[-\s]?noranda\b/i, /\babitibi\b/i] },
  { canonical: "Val-d'Or", patterns: [/\bval[-\s]?d['']?or\b/i] },
  { canonical: "Rimouski", patterns: [/\brimouski\b/i, /\bbas[-\s]?st?[-\s]?laurent\b/i] },
  { canonical: "Sept-Îles", patterns: [/\bsept[-\s]?[iîíì]les?\b/i, /\bc[ôo]te[-\s]?nord\b/i] },
  { canonical: "Gaspé", patterns: [/\bgasp[eé](?:sie)?\b/i] },
  { canonical: "Lévis", patterns: [/\bl[ée]vis\b/i] },
  { canonical: "Joliette", patterns: [/\bjoliette\b/i, /\blanaudi[eè]re\b/i] },
  { canonical: "Saint-Jean-sur-Richelieu", patterns: [/\bsaint?[-\s]?jean[-\s]?sur[-\s]?richelieu\b/i] },
];

// Each entry maps an intent to ALL category slugs that may carry those services
// in the DB. We MUST list both EN and FR slugs because the production data
// carries both (legacy of separate import scripts — `food` AND `alimentation`,
// `health` AND `sante`, etc.). Listing only the EN slug used to drop 50%+ of
// matches. To be cleaned up post-launch with a one-time UPDATE migration.
const CATEGORY_KEYWORDS: { slugs: string[]; patterns: RegExp[] }[] = [
  { slugs: ["housing", "logement"],            patterns: [/\b(logement|h[eé]berg\w*|sans[-\s]?abri|itin[eé]rance|refuge|dorm\w*|[ée]viction|expulsion|shelter|homeless|housing|appartement|loyer)\b/i] },
  { slugs: ["food", "alimentation"],           patterns: [/\b(nourriture|faim|manger|banque\s+alimentaire|popote|food|hungry|meal|repas|alimentation)\b/i] },
  { slugs: ["mentalHealth", "santemental"],    patterns: [/\b(d[eé]pression|suicid\w*|anxi[eé]t\w*|crise|sant[eé]\s+mentale|psy(?:cho|chiatre|chologue)?\b|mental|th[eé]rapie|therapy|d[eé]tresse)\b/i] },
  { slugs: ["health", "sante"],                patterns: [/\b(malade|m[eé]decin|doctor|clsc|h[oô]pital|ambulance|soins|sick|maladie|douleur)\b/i] },
  { slugs: ["immigration"],                    patterns: [/\b(immigr\w*|r[eé]fugi[eé]\w*|papiers|sans[-\s]?papiers?|asile|ircc|mifi|csq|parrainage|asylum|sponsorship|nouveau\s+arrivant|nouvelle\s+arrivante|visa)\b/i] },
  { slugs: ["employment", "emploi"],           patterns: [/\b(emploi|travail|job|cje|ch[oô]mage|work|unemployed|formation|carri[eè]re)\b/i] },
  { slugs: ["family", "famille"],              patterns: [/\b(famille|enfant|conjugal|violence|dpj|victime|family|child|abuse|maltraitance)\b/i] },
  { slugs: ["social", "soutienSocial"],        patterns: [/\b(centraide|211|r[eé]f[eé]rence\s+communautaire|organisme\s+communautaire)\b/i] },
  { slugs: ["childcare"],                      patterns: [/\b(garderie|cpe|daycare|garde\s+(?:d['']enfant|en\s+milieu))\b/i] },
  { slugs: ["legal"],                          patterns: [/\b(juridique|avocat|notaire|droit|legal|lawyer|aide\s+juridique)\b/i] },
  { slugs: ["seniors"],                        patterns: [/\b(a[iî]n[eé]\w*|vieillesse|alzheimer|fadoq|retraite|senior|elder|proche\s+aidant|chsld|popote\s+roulante)\b/i] },
  { slugs: ["realestate", "achatImmobilier"],  patterns: [/\b(achat\s+(?:de\s+)?maison|hypoth[eè]que|mortgage|schl|premi[eè]re\s+(?:maison|propri[eé]t[eé])|first[-\s]?home|propri[eé]taire)\b/i] },
  { slugs: ["banking"],                        patterns: [/\b(banque|compte\s+bancaire|desjardins|scotia|rbc|td|bmo|laurentienne|caisse\s+populaire|bank)\b/i] },
  { slugs: ["transport"],                      patterns: [/\b(transport|m[eé]tro|stm|rtc|stl|rtl|opus|autobus|\bbus\b)/i] },
  { slugs: ["moving"],                         patterns: [/\b(d[eé]m[eé]nag\w*|mover|moving)\b/i] },
  { slugs: ["pharmacie"],                      patterns: [/\b(pharmacie|pharmacy|m[eé]dicament)\b/i] },
];

const URGENT_PATTERNS = /\b(urgent|maintenant|tout\s+de\s+suite|asap|danger|en\s+crise|urgence|emergency|now|help\s+me|aide[-\s]moi|imm[eé]diatement|sos)\b/i;

function extractKeywords(message: string, history: { role: string; content: string }[]): Keywords {
  // Pull recent user turns into the search text so short follow-ups
  // ("et à Trois-Rivières?") still inherit context from prior questions.
  const recentUser = history.filter((h) => h.role === "user").slice(-2).map((h) => h.content).join(" ");
  const text = `${recentUser} ${message}`;

  const cities: string[] = [];
  for (const { canonical, patterns } of CITY_PATTERNS) {
    if (patterns.some((p) => p.test(text))) cities.push(canonical);
  }

  const categories: string[] = [];
  for (const { slugs, patterns } of CATEGORY_KEYWORDS) {
    if (patterns.some((p) => p.test(text))) categories.push(...slugs);
  }

  // Urgency only from the CURRENT message — we don't want a one-off "urgent"
  // from 5 turns ago to keep boosting urgent services forever.
  const isUrgent = URGENT_PATTERNS.test(message);
  return { cities, categories, isUrgent };
}

type RetrievedService = {
  id: string; name: string; category: string; subcategory: string;
  city: string; phone: string; description: string;
  isUrgent: boolean; isProvinceWide: boolean;
};

async function retrieveServices(kw: Keywords): Promise<RetrievedService[]> {
  const conditions: SQL[] = [eq(servicesTable.active, true)];

  if (kw.cities.length > 0) {
    // Match the city directly OR include province-wide entries — the latter
    // are valid answers everywhere and we don't want to hide pw1/pw2/etc.
    const cityClauses = kw.cities.map((c) => ilike(servicesTable.city, `%${c}%`));
    const cityOrPw = or(...cityClauses, eq(servicesTable.isProvinceWide, true));
    if (cityOrPw) conditions.push(cityOrPw);
  }

  if (kw.categories.length > 0) {
    conditions.push(inArray(servicesTable.category, kw.categories));
  }

  try {
    const rows = await db
      .select({
        id: servicesTable.id,
        name: servicesTable.name,
        category: servicesTable.category,
        subcategory: servicesTable.subcategory,
        city: servicesTable.city,
        phone: servicesTable.phone,
        description: servicesTable.description,
        isUrgent: servicesTable.isUrgent,
        isProvinceWide: servicesTable.isProvinceWide,
      })
      .from(servicesTable)
      .where(and(...conditions))
      .orderBy(
        // In a crisis, urgent services come first. Otherwise we put local
        // (non-province-wide) services first so the user gets actionable
        // hyper-local answers instead of generic 1-800 lines.
        kw.isUrgent ? desc(servicesTable.isUrgent) : asc(servicesTable.isProvinceWide),
        desc(servicesTable.isUrgent),
        asc(servicesTable.name),
      )
      .limit(15);
    return rows;
  } catch {
    // Fail-soft — caller falls back to the static catalog so the user
    // never sees a blank response just because the DB hiccupped.
    return [];
  }
}

function formatServicesForPrompt(rows: RetrievedService[]): string {
  if (rows.length === 0) return "";
  return rows.map((r) => {
    const tags: string[] = [];
    if (r.isUrgent) tags.push("URGENT");
    if (r.isProvinceWide) tags.push("province");
    const tagStr = tags.length ? ` [${tags.join(",")}]` : "";
    const phoneStr = r.phone ? ` | Tél:${r.phone}` : "";
    const cityStr = r.city ? ` (${r.city})` : "";
    const descStr = r.description ? ` — ${r.description.slice(0, 110)}` : "";
    const sub = r.subcategory ? `/${r.subcategory}` : "";
    return `- ID:${r.id} | ${r.name}${cityStr} | ${r.category}${sub}${descStr}${phoneStr}${tagStr}`;
  }).join("\n");
}

// Always-injected safety net — these tiny lifelines stay in EVERY prompt
// regardless of intent detection, so the model never misses a crisis line.
const SAFETY_LIFELINES = `LIGNES DE SECOURS PROVINCIALES (à mentionner si la situation l'exige) :
- ID:pw1 | 211 Québec | Référence communautaire toutes catégories | Tél:211
- ID:pw2 | Info-Santé 811 | Santé - infirmières 24h | Tél:811
- ID:pw3 | SOS Violence Conjugale | Violence conjugale 24h | Tél:1-800-363-9010
- ID:pw4 | DPJ Protection de la jeunesse | Enfants en danger | Tél:1-800-463-9019
- ID:pw5 | Suicide Action / Tel-Jeunes | Prévention suicide 24h | Tél:1-866-APPELLE
- ID:pw6 | Tel-Aide Québec | Écoute anonyme | Tél:514-935-1101
- ID:pw7 | Emploi-Québec | Emploi / formations | Tél:1-888-643-4721
- ID:pw8 | TCRI | Réfugiés et demandeurs d'asile | Tél:514-272-6060
- ID:pw9 | Hébergement femmes battues | Femmes violences | Tél:514-879-9010
- ID:pw10 | RSIQ | Itinérance | Tél:514-933-9373
- 911 | Urgence police/pompiers/ambulance partout au Québec | Tél:911`.trim();

function buildSystemPrompt(language: string, retrievedBlock: string): string {
  const isEn = language === "en";
  const isEs = language === "es";
  const isAr = language === "ar";
  const isHt = language === "ht";

  let langInstruction = "";
  if (isEn) {
    langInstruction =
      "Respond in English. The user may not speak French well. Be welcoming and clear.";
  } else if (isEs) {
    langInstruction =
      "Respond in Spanish (español). The user is likely a Spanish-speaking immigrant. Be welcoming and clear.";
  } else if (isAr) {
    langInstruction =
      "Respond in Arabic (العربية). The user is likely an Arabic-speaking immigrant. Be welcoming and clear.";
  } else if (isHt) {
    langInstruction =
      "Respond in Haitian Creole (Kreyòl ayisyen). The user is likely a Haitian Creole speaker. Be welcoming and clear.";
  } else {
    langInstruction =
      "Respond in French (Québec). The user is in Québec. Be welcoming and clear.";
  }

  const timeContext = getQuebecTimeContext();

  return `You are AttenteZéro — a compassionate AI guide and emergency coordinator helping vulnerable people in QUÉBEC find community, social, and emergency services.

GEOGRAPHIC SCOPE — QUÉBEC UNIQUEMENT:
- Tu aides EXCLUSIVEMENT les personnes au Québec. Toute la base de connaissances (5 700+ services locaux, banques, transport, tourisme, déménagement, top 10 immigration, aide financière, glossaire) est centrée sur le Québec.
- Si l'usager mentionne une autre province ou territoire (Ontario, Alberta, etc.) : redirige-le poliment vers le 211 de sa province et Service Canada, puis arrête là. Ne recommande PAS de services québécois hors Québec.
- Pour les urgences (911, 988 prévention suicide, lignes de crise pancanadiennes) : aide toujours, peu importe la géographie.
- Régions couvertes en détail au Québec : Montréal, Québec (ville), Laval, Gatineau/Outaouais, Longueuil/Montérégie, Sherbrooke/Estrie, Trois-Rivières/Mauricie, Saguenay-Lac-St-Jean, Abitibi-Témiscamingue, Côte-Nord, Bas-St-Laurent, Gaspésie, et toutes les autres régions administratives québécoises.


${langInstruction}

Your role:
- Listen carefully to the person's situation with empathy
- Identify their needs: housing, food, mental health, health, immigration, employment, family, social support, childcare, emergency
- Recommend the most relevant services — including emergency services when appropriate
- Be warm, non-judgmental, trauma-informed, and concise
- Use the time context below to anticipate risks and give proactive safety advice

${timeContext}

INTELLIGENCE PRÉDICTIVE — utilise le contexte temporel pour:
- Mentionner les risques saisonniers ou horaires pertinents si la situation l'exige
- Prioriser les ressources d'hébergement d'urgence la nuit en hiver
- Avertir des risques d'hypothermie pour les personnes sans abri par temps froid
- Alerter sur les risques d'intoxication en soirée de fin de semaine
- Signaler les risques d'inondations au printemps pour les zones à risque
- Recommander de l'eau et de l'ombre en période de canicule

CENTRALISATION DES SERVICES D'URGENCE — pour toute urgence, TOUJOURS mentionner:
1. Composez le 911 en PREMIER (police + pompiers + ambulance via dispatch centralisé)
2. Le 911 coordonne automatiquement les services disponibles dans la région
3. Préciser que 773 des 1 112 municipalités n'ont pas de premiers répondants — délais possibles

CRITICAL SITUATIONS — respond to these with the highest priority:
- Suicide, self-harm, wanting to die: START with 911 + Suicide Action (1-866-APPELLE). They are not alone.
- Domestic violence, assault, immediate danger: START with 911 + SOS Violence conjugale (1-800-363-9010).
- Child in danger: START with 911 + DPJ (1-800-463-9019).
- Fire / building emergency: START with 911 + local fire service.
- Medical emergency: START with 911 + Urgences-santé or regional ambulance.
- Drug overdose: START with 911 + Drogue : aide et référence (1-800-265-2626).
- Elder abuse: START with Aide Abus Aînés (1-888-489-2287) + 911 if immediate danger.
- For any urgent/crisis: be brief, direct, reassuring. Do NOT overwhelm.

PROFESSIONAL REFERRALS — proactively recommend:
- Mental health / addiction: psychologist, travailleur social, pw5, crisis centres.
- Family conflict or violence: social worker, family mediator.
- Immigration complex situations: legal consultant or lawyer.
- Chronic health: doctor or community health clinic.

GUIDES INTERNES DE L'APP — recommande l'écran approprié quand le sujet correspond. Utilise toujours le nom EXACT entre guillemets pour que l'usager puisse le trouver dans l'app:
- "Aide financière" : calculatrice + démarches pour Allocation famille (Retraite Québec), RQAP (congé parental), Aide sociale, Solidarité sociale, Allocation-logement, Crédit solidarité, Prime au travail, etc.
- "Top 10 à faire" : 10 étapes prioritaires selon le statut d'immigration (visiteur, travailleur qualifié, étudiant, demandeur d'asile) avec barre de progression.
- "Glossaire" : définitions des sigles et termes (NAS, RAMQ, IRCC, MIFI, CSQ, AFE, CPE, CIUSSS, etc.).
- "Déménagement" : guide complet déménagement au Québec — règles 1er juillet, 22 déménageurs par région (Montréal, Québec, Laval, Estrie, Longueuil, Outaouais), liens vérification CTQ + OPC, comparateurs (411, Soumissions Déménagement, Sirelo, Mover.net, Myette, Top10).
- "Guide d'achat immobilier" : guide complet achat maison au Québec en 8 étapes, banques et marchés régionaux.
- "Banques" (catégorie services) : 53 fiches institutions financières au Québec (Desjardins, Banque Nationale, BMO, RBC, TD, Scotia, Laurentienne, banques numériques, coopératives).
- "Transport" (catégorie services) : 60 fiches transport (STM, RTC, STL, RTL, exo, OPUS, BIXI, Communauto, taxi adapté, transport collectif régional, OnRoule, REM).
- "Tourisme" (catégorie services) : 17 fiches tourisme (Bonjour Québec, Sépaq, Société des musées, festivals, ATR régionales).
- Quand pertinent, écris par exemple : « Ouvrez l'écran "Déménagement" dans l'app pour la liste complète » ou « La calculatrice "Aide financière" peut estimer vos prestations ».

When recommending services, include their IDs in this exact format at the END of your message:
[SERVICES: id1, id2, id3]

Only include service IDs from the catalogs below. For urgent situations, prefer services marked "urgent". Match the city/region when known.

CITATION OBLIGATOIRE — pour CHAQUE service recommandé dans le corps du message, tu DOIS écrire en clair :
- Le nom EXACT du service (en gras avec **nom**)
- Le numéro de téléphone EXACT tel qu'il apparaît après "Tél:" dans le catalogue
- Format : « **Nom du service** — appelez le 514-XXX-XXXX » ou « **Nom** (Tél. 1-800-XXX-XXXX) »
- N'invente JAMAIS un numéro. Si un service n'a pas de "Tél:" dans le catalogue, ne mets pas de numéro.
- Pour la catégorie aînés (isolement, abus, popote roulante, transport adapté, Alzheimer, FADOQ, retraite, proches aidants, maintien à domicile, CHSLD), pioche EN PRIORITÉ dans les sections "AÎNÉS" du catalogue ci-dessous.

EMERGENCY SERVICES CATALOG:
(Note : la section "AUTRES PROVINCES ET TERRITOIRES" sert UNIQUEMENT à rediriger un Québécois qui aurait un proche hors-Québec ou qui prévoit déménager. Elle ne doit JAMAIS être proposée comme service principal — l'utilisateur de l'app est au Québec.)
${EMERGENCY_CATALOG}

${SAFETY_LIFELINES}

COMMUNITY SERVICES CATALOG (LIVE — extrait dynamiquement de la base de données ${retrievedBlock ? "selon la question de l'usager" : "(aucun match — utiliser les lignes de secours et le catalogue de référence ci-dessous)"}):
${retrievedBlock || SERVICES_CATALOG}

Guidelines:
- Keep responses under 200 words
- Always end with the [SERVICES: ...] tag if recommending any services
- If unsure about region, recommend province-wide services (pw1–pw10) from the safety lifelines above
- For emergency queries, always start with 911 instruction
- Never make up service IDs — only use IDs from the catalogs above (LIVE catalog IDs are real database identifiers — use them verbatim)
- Never be dismissive — every situation deserves a caring, actionable response
- For mental health and crisis topics: validate feelings first, then provide resources`;
}

router.post("/ai/chat", async (req, res) => {
  const {
    message,
    language: bodyLanguage = "fr",
    history = [],
    source = "main",
  } = req.body as {
    message?: string;
    language?: string;
    history?: { role: "user" | "assistant"; content: string }[];
    source?: "main" | "floating";
  };
  const language = bodyLanguage;
  const isFloating = source === "floating";

  // ── Authentication guard ───────────────────────────────────────
  // Main chat tab: signed-in members only (server-side enforcement so the
  // endpoint cannot be used as a public OpenAI proxy by callers who bypass
  // the mobile UI).
  // Floating chatbot: open to everyone (free for all users) — quota-protected
  // by IP to keep AI costs bounded.
  const sid = getSessionId(req);
  const session = sid ? await getSession(sid) : null;
  if (!isFloating && !session?.user?.id) {
    res.status(401).json({
      error: language === "en"
        ? "AI chat is reserved for signed-in members."
        : "Le chat IA est réservé aux membres connectés.",
    });
    return;
  }

  if (!message || typeof message !== "string") {
    res.status(400).json({ error: "message is required" });
    return;
  }

  // ── Quota check ──────────────────────────────────────────────
  // Premium → unlimited everywhere.
  // Floating chatbot (non-Premium) → 15/day during a 3-day free trial.
  //   Day 1, 2, 3 from first message: up to 15 questions/day.
  //   Day 4 and beyond: 429 trialExpired + Premium CTA.
  // Main chat tab (free users) → 5/day per user (unchanged).
  const { isPremium, userId } = await getUserPremiumStatus(req);
  if (!isPremium) {
    const limit = isFloating ? FLOATING_DAILY_LIMIT : FREE_DAILY_LIMIT;
    // Separate quota bucket per source so floating usage doesn't burn the
    // main-chat allowance and vice-versa.
    const baseKey = clientKey(req, userId);
    const key = `${isFloating ? "f:" : "m:"}${baseKey}`;

    // Floating: enforce the 3-day trial window (persistent in DB).
    if (isFloating) {
      const trialStart = await getOrCreateTrialStart(baseKey);
      if (trialStart && daysSince(trialStart) >= FLOATING_TRIAL_DAYS) {
        res.status(429).json({
          error: language === "en"
            ? `Your ${FLOATING_TRIAL_DAYS}-day free trial of the AI assistant has ended. Upgrade to Premium to keep chatting.`
            : `Votre essai gratuit de ${FLOATING_TRIAL_DAYS} jours de l'assistant IA est terminé. Passez à Premium pour continuer à discuter.`,
          quotaExceeded: true,
          trialExpired: true,
          trialDays: FLOATING_TRIAL_DAYS,
          upgradeUrl: "/premium",
        });
        return;
      }
    }

    const q = bumpQuota(key, limit);
    if (q.count > q.limit) {
      res.status(429).json({
        error: language === "en"
          ? `You've reached your ${q.limit} free questions for today. Try again tomorrow or upgrade to Premium for unlimited access.`
          : `Vous avez utilisé vos ${q.limit} questions gratuites pour aujourd'hui. Réessayez demain ou passez à Premium pour un accès illimité.`,
        quotaExceeded: true,
        limit: q.limit,
        upgradeUrl: "/premium",
      });
      return;
    }
    // Inform client of remaining quota via headers
    res.setHeader("X-AI-Quota-Limit", String(q.limit));
    res.setHeader("X-AI-Quota-Remaining", String(q.remaining));
  }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("Access-Control-Allow-Origin", "*");

  try {
    // ── RAG retrieval (Option A) ─────────────────────────────────
    // Pull the 15 most relevant LIVE services from the DB for this question
    // and inject them in place of the static SERVICES_CATALOG. Falls back
    // silently to the static catalog if the DB returns nothing.
    const keywords = extractKeywords(message, history);
    const retrieved = await retrieveServices(keywords);
    const retrievedBlock = formatServicesForPrompt(retrieved);
    req.log.info(
      { cities: keywords.cities, categories: keywords.categories, urgent: keywords.isUrgent, retrievedCount: retrieved.length },
      "AI chat retrieval",
    );

    const messages: { role: "system" | "user" | "assistant"; content: string }[] =
      [
        { role: "system", content: buildSystemPrompt(language, retrievedBlock) },
        ...history.slice(-6).map((h) => ({
          role: h.role as "user" | "assistant",
          content: h.content,
        })),
        { role: "user", content: message },
      ];

    const stream = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      max_tokens: 600,
      messages,
      stream: true,
    });

    let fullResponse = "";

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content;
      if (content) {
        fullResponse += content;
        res.write(`data: ${JSON.stringify({ content })}\n\n`);
      }
    }

    const serviceMatch = fullResponse.match(/\[SERVICES:\s*([^\]]+)\]/);
    const serviceIds = serviceMatch
      ? serviceMatch[1]
          .split(",")
          .map((s) => s.trim().replace(/^ID:/i, ""))
          .filter(Boolean)
      : [];

    res.write(
      `data: ${JSON.stringify({ done: true, serviceIds })}\n\n`
    );
    res.end();
  } catch (err: unknown) {
    const message =
      err instanceof Error ? err.message : "Unknown error";
    req.log.error({ err }, "AI chat error");
    res.write(`data: ${JSON.stringify({ error: message })}\n\n`);
    res.end();
  }
});

export default router;
