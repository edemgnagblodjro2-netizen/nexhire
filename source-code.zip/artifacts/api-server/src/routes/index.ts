import { Router, type IRouter } from "express";
import healthRouter from "./health";
import aiRouter from "./ai";
import transcribeRouter from "./transcribe";
import authRouter from "./auth";
import captchaRouter from "./captcha";
import stripeRouter from "./stripe";
import servicesRouter from "./services";
import serviceCorrectionsRouter from "./serviceCorrections";
import serviceRatingsRouter from "./serviceRatings";
import organisationsRouter from "./organisations";
import verificationsRouter from "./verifications";
import b2gRouter from "./b2g";
import waitRouter from "./wait";
import bugReportsRouter from "./bugReports";
import searchEventsRouter from "./searchEvents";
import analyticsRouter from "./analytics";
import referralsRouter from "./referrals";
import storeStatusRouter from "./storeStatus";
import contactRouter from "./contact";
import tenantsRouter from "./tenants";
import tenantAuthRouter from "./tenant-auth";
import queueRouter from "./queue";
import attentezeroRouter from "./attentezero";
import endorsementsRouter from "./endorsements";

// Pivot v1.0.33 — sensitive-data modules retired:
// `clients`, `appointments`, `team`, and the activity-feed endpoints have been
// pulled from the public surface. The route files and DB tables are kept on
// disk so the work can be revived if the product direction changes, but
// nothing routes traffic into them anymore. This eliminates AttenteZéro's
// custodianship of beneficiary case-files and lets us focus the offering on
// the public-facing directory + AI assistant + B2G dashboards.

const router: IRouter = Router();

router.use(healthRouter);
router.use(aiRouter);
router.use(transcribeRouter);
router.use(authRouter);
router.use(captchaRouter);
router.use(stripeRouter);
router.use(servicesRouter);
router.use(serviceCorrectionsRouter);
router.use(serviceRatingsRouter);
router.use(organisationsRouter);
router.use(verificationsRouter);
router.use(b2gRouter);
router.use(waitRouter);
router.use(bugReportsRouter);
router.use(searchEventsRouter);
router.use(analyticsRouter);
router.use(referralsRouter);
router.use(storeStatusRouter);
router.use(contactRouter);
router.use("/admin/tenants", tenantsRouter);
router.use("/tenant-auth", tenantAuthRouter);
router.use(queueRouter);
router.use("/", attentezeroRouter);
router.use(endorsementsRouter);

export default router;
